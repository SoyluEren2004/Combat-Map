using System.Collections.Generic;
using UnityEngine;

public class Groups : MonoBehaviour
{
    public List<Character> characters;

    public Groups(List<Character> characters)
    {
        this.characters = characters;
    }

    public int GetTotalHP()
    {
        int TotalHP = 0;
        foreach (Character C in characters)
        {
            TotalHP += C.hp;
        }
        return TotalHP;
    }

    public int GetTotalAttackPower()
    {
        int TotalAttack = 0;
        foreach (Character C in characters)
        {
            TotalAttack += C.strength;
        }
        return TotalAttack;
    }

    public void TakeDamage(int Damage)
    {
        foreach (Character C in characters)
        {
            C.hp -= Damage;
            if (C.hp <= 0)
                C.hp = 0;
            else
            {
                // d���nmedim daha
            }
        }
    }
}