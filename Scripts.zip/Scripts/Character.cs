using UnityEngine;

public class Character : MonoBehaviour
{
    public new string name;
    public int hp;
    public int strength;
    public int level;
    public int exp;

    public Character(string name, int hp, int strength)
    {
        this.name = name;
        this.hp = hp;
        this.strength = strength;
        this.level = 1;
        this.exp = 0;
    }

    public void LevelUp()
    {
        level++;
        hp += 10; 
        strength += 10; 
    }

    public void GainExp(int amount)
    {
        exp += amount;
        if (exp >= 100)
        {
            exp -= 100;
            LevelUp();
        }
        else
        {
            //bilmiyorum buray� bakar�z.
        }
    }
}
