using UnityEngine;
using UnityEngine.PlayerLoop;

public class Map : MonoBehaviour
{
    public BattleSystem battle; 

    void Start()
    {
        battle = Object.FindAnyObjectByType<BattleSystem>();
    }

    public void ShowMap()
    {
        Debug.Log("1 - Se�enek 1");
        Debug.Log("2 - Se�enek 2");
        Debug.Log("3 - Se�enek 3");
    }


    public void HandleSelection(Groups GroupA, Groups GroupB)
    {
        if (battle == null) 
        {
            Debug.LogError("BattleSystem bulunamad�! Sahneye ekledi�inden emin ol.");
            return;
        }

        battle.Initialize(GroupA, GroupB); 

        Groups winner = battle.StartBattle(); 

        if (winner == null)
        {
            Debug.Log("Sava� berabere bitti!");
        }
        else
        {
            Debug.Log(winner == GroupA ? "A grubu kazand�!" : "B grubu kazand�!");
            winner.characters.ForEach(C => C.GainExp(50)); 
        }
    }
}
