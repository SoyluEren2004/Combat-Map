using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public Groups GroupA;
    public Groups GroupB;
    private Map map;

    void Start()
    {
       
        GroupA = new Groups(new List<Character> { });
        GroupB = new Groups(new List<Character> { });

        map = new Map();
        map.ShowMap(); 
    }

    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            map.HandleSelection( GroupA, GroupB);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            map.HandleSelection( GroupA, GroupB);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            map.HandleSelection( GroupA, GroupB);
        }
    }
}