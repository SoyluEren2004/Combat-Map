using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum BattleState { START, WON, LOST, DRAW }

public class BattleSystem : MonoBehaviour
{
    public Groups GroupA;
    public Groups GroupB;

    public GameObject playerPrefab;
    public GameObject enemyPrefab;

    public Transform playerBattleStation;
    public Transform enemyBattleStation;

    public BattleState state;

    void Start()
    {
        state = BattleState.START;
        SetupBattle();
        StartCoroutine(BattleRoutine()); 
    }

    IEnumerator BattleRoutine()
    {
        yield return new WaitForSeconds(1f);
        Groups winner = StartBattle();
        Debug.Log($"Sava� sonucu: {state}");
    }


    public void Initialize(Groups groupA, Groups groupB)
    {
        this.GroupA = groupA;
        this.GroupB = groupB;
    }

    void SetupBattle()
    {
        Instantiate(playerPrefab, playerBattleStation.position, Quaternion.identity, playerBattleStation);
        Instantiate(enemyPrefab, enemyBattleStation.position, Quaternion.identity, enemyBattleStation);
    }

    public Groups StartBattle()
    {
        int DamageToB = GroupA.GetTotalAttackPower();
        int DamageToA = GroupB.GetTotalAttackPower();

        GroupB.TakeDamage(DamageToB);
        GroupA.TakeDamage(DamageToA);

        if (GroupA.GetTotalHP() > GroupB.GetTotalHP())
        {
            state = BattleState.WON;
            return GroupA;
        }
        else if (GroupA.GetTotalHP() < GroupB.GetTotalHP())
        {
            state = BattleState.LOST;
            return GroupB;
        }
        /*else if (GroupA.GetTotalHP() == GroupB.GetTotalHP())
        {
            state = BattleState.DRAW;
            return null;
            burda return null dedi�imde not all code paths return a value hatas� al�yorum groupsdan nulla
            d�n��t�r�p draw etmek istiyordum yapamad�m o yuzden else if kullanmadan yapt�m bir s�k�nt� c�kar m� bilmiom
            */
        state = BattleState.DRAW;
        return null;
    }
}

